# Netwerktools in Python: een TCP proxy bouwen

KM / Ethical Hacking Week 2

"A TCP proxy server is a server that acts as an intermediary between a client and another server, called the destination server. Clients establish connections to the TCP proxy server, which then establishes a connection to the destination server. The proxy server sends data received from the client to the destination server and forwards data received from the destination server to the client. Interestingly, the TCP proxy server is actually both a server and a client. It is a server to its client and a client to its destination server. A TCP proxy server can be useful to get around services which restrict connections based on the network addresses."


Onze proxy bestaat uit 4 hoofdfuncties
- We moeten in de console de communicatie weergeven tussen de lokale en de remote machines: hexdump
- We moeten van een inkomende socket data ontvangen van ofwel de lokale of de remote machine: receive
_from 
- We moeten de data richting managen tussen de remote en lokale machines: proxy_handler 
- We moeten een listener socket kunnen opzetten en meegeven aan onze proxy_handler: server_loop.

```python
import sys
import socket
import threading

HEX_FILTER = ''.join(
    [(len(repr(chr(i))) == 3) and chr(i) or '.' for i in range(256)])


def hexdump(src, length=16, show=True):
    if isinstance(src, bytes):
        src = src.decode()
    results = list()
    for i in range(0, len(src), length):
        word = str(src[i:i+length])
        printable = word.translate(HEX_FILTER)
        hexa = ' '.join([f'{ord(c):02X}' for c in word])
        hexwidth = length*3
        results.append(f'{i:04x}  {hexa:<{hexwidth}}  {printable}')
    if show:
        for line in results:
            print(line)
    else:
        return results
```

- Eerst enkele noodzakelijk imports
- Vervolgens een hexdump functie die input als bytes of string aanneemt en een hexdump afdrukt naar de console
- Deze functie geeft de packet details terug met zowel hun hexadecimale waarden als de ASCII-karakters
- Dit is o.m. handig om onbekende protocollen te begrijpen, user credentials terug te vinden in plain text protocollen.
- We maken een HEX_FILTER string die de ASCII-karakters bevat, of een "." indien er geen ASCII-representatie bestaat

De karakter-representatie van 65 is afdrukbaar en die van 30 niet. De representatie van het afdrukbare karakter heeft een lengte van 3 => we gebruiken dit om de string te creëren.

```python
>>> chr(65)
'A'
>>> chr(30)
'\x1e'
>>> len(repr(chr(65)))
3
>>> len(repr(chr(30)))
6
```

De string die wordt aangemaakt in de list comprehension (https://www.geeksforgeeks.org/python-list-comprehension/) ziet er uit als volgt:

```python
'................................ !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJK
LMNOPQRSTUVWXYZ[.]^_`abcdefghijklmnopqrstuvwxyz{|}~...........................
.......¡¢£¤¥¦§ ̈©a«¬.® ̄°±23 ́μ¶· ̧1o»1⁄41⁄23⁄4¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæç
èéêëìíîïðñòóôõö÷øùúûüýþÿ'
```

Vervolgens wordt de hexdump functie gemaakt:
- We checken eerst of we een string hebben en decoden de bytes als we effectief een string hebben ontvangen 
- Dan nemen we een deel van de string en stoppen we hem in de 'word' variabele
- We gebruiken de ingebouwde functie translate om de string representatie van elk karakter te vervangen door het overeenkomstige karakter in de raw string (printable) 
- Op dezelfde manier vervangen we de hex representatie van de integerwaarde van elk karakter in de raw string (hexa)
- Tot slot maken we een nieuwe array om de strings vast te houden, result, die de hexwaarde van de index van de eerste byte in het woord, de hexwaarde van het woord en zijn printvriendelijke representatie bevat

```python
>> hexdump('python rocks\n and proxies roll\n')
0000 70 79 74 68 6F 6E 20 72 6F 63 6B 73 0A 20 61 6E    python rocks. an
0010 64 20 70 72 6F 78 69 65 73 20 72 6F 6C 6C 0A       d proxies roll.
```

Bovenstaande functie voorziet ons van een manier om in realtime de communicatie te bekijken die door een proxy gaat.

Vervolgens buigen we ons over de functie die beide kanten van de proxy gaan gebruiken om data te ontvangen:


```python
def receive_from(connection):
    buffer = b""
    connection.settimeout(10)
    try:
        while True:
            data = connection.recv(4096)
            if not data:
                break

            buffer += data
    except Exception as e:
        print('error ', e)
        pass

    return buffer
```

- Om zowel lokale als remote data te ontvangen geven we het socket object ter gebruik mee
- We maken een lege byte string, buffer, die de antwoorden van de socket zal verzamelen
- Standaard zetten we een 5 seconden time-out (je kan deze hoger zetten indien nodig)
- We creëren een loop om de response data in de buffer in te lezen, tot er geen data meer is of we een time-out krijgen
- Tot slot geven we de buffer byte string terug aan de caller (i.e. lokale of remote machine)

In bepaalde gevallen zal je de response of requests packets willen aanpassen vooraleer de proxy ze doorstuurt. We gaan hiervoor al functies creëren (request_handler en response_handler):

```python
def request_handler(buffer):
    # perform packet modifications
    return buffer


def response_handler(buffer):
    # perform packet modifications
    return buffer
```

Binnen deze functies kan je de inhoud van packets aanpassen, maar ook tal van andere zaken doen. Bvb scannen wanneer niet-geëncrypteerde wachtwoorden de revue passeren.

We bekijken nu de proxy_handler functie: 

```python
def proxy_handler(client_socket, remote_host, remote_port, receive_first):
    remote_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    remote_socket.connect((remote_host, remote_port))

    if receive_first:
        remote_buffer = receive_from(remote_socket)
        if len(remote_buffer):
            print("[<==] Received %d bytes from remote." % len(remote_buffer))
            hexdump(remote_buffer)

            # remote_buffer = response_handler(remote_buffer)
            # client_socket.send(remote_buffer)
            # print("[==>] Sent to local.")

    while True:
        local_buffer = receive_from(client_socket)
        if len(local_buffer):
            print("[<==] Received %d bytes from local." % len(local_buffer))
            hexdump(local_buffer)

            local_buffer = request_handler(local_buffer)
            remote_socket.send(local_buffer)
            print("[==>] Sent to remote.")

        remote_buffer = receive_from(remote_socket)
        if len(remote_buffer):
            print("[<==] Received %d bytes from remote." % len(remote_buffer))
            hexdump(remote_buffer)

            remote_buffer = response_handler(remote_buffer)
            client_socket.send(remote_buffer)
            print("[==>] Sent to local.")

        if not len(local_buffer) or not len(remote_buffer):
            client_socket.close()
            remote_socket.close()
            print("[*] No more data. Closing connections.")
            break
```

- Deze functie bevat het grootste deel van de logica voor onze proxy.
- Om te beginnen maken we de connectie naar de remote host
- We checken vervolgens om zeker te zijn dat we niet eerst een connectie moeten initiëren naar de remote kan en data opvragen vooraleer we naar de main loop gaan
- Bepaalde server daemons verwachten dit namelijk (FTP servers bvb zenden eerst een banner)
- We gebruiken daarop de receive_from functie voor beide kanten van de communicatie. Deze accepteert een verbonden socket object en doet een receive
- We dumpen de inhoud van het packet zodat we het kunnen inspecteren
- Vervolgens geven we de output aan de response_handler functie en sturen de ontvangen buffer naar de lokale client
- Daarna zetten we onze loop in gang om doorlopend te lezen van de lokale client, de data te processen, door te sturen naar de remote client, lezen van de remote client, de data te processen en door te sturen naar de lokale client tot we geen data meer detecteren
- Wanneer er geen data meer is te sturen langs beide kanten van de connectie sluiten we de lokale en remote sockets af en stoppen we de loop


Vervolgens ontwikkelen we de server_loop functie om de connectie op te zetten en te beheren:

```python
def server_loop(local_host, local_port, remote_host, remote_port, receive_first):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        server.bind((local_host, local_port))
    except Exception as e:
        print("[!!] Failed to listen on %s:%d" % (local_host, local_port))
        print("[!!] Check for other listening sockets or correct permissions.")
        print(e)
        sys.exit(0)

    print("[*] Listening on %s:%d" % (local_host, local_port))
    server.listen(5)
    while True:
        client_socket, addr = server.accept()
        print("> Received incoming connection from %s:%d" % (addr[0], addr[1]))
        
        proxy_thread = threading.Thread(
            target=proxy_handler,
            args=(client_socket, remote_host,
                  remote_port, receive_first))
        proxy_thread.start()
```

- Deze functie creëert een socket, bindt ze aan de lokale host en luistert.
- In de main loop, als een nieuwe connectie request binnenkomt, geven we deze door aan de proxy_handler in een nieuwe thread
- Deze verzorgt alle sturen en ontvangen naar beide zijden van de datastroom

Laatste functie die we voorzien is de main:

```python
def main():
    if len(sys.argv[1:]) != 5:
        print("Usage: ./proxy.py [localhost] [localport]", end='')
        print("[remotehost] [remoteport] [receive_first]")
        print("Example: ./proxy.py 127.0.0.1 9000 10.12.132.1 9000 True")
        sys.exit(0)
    
    local_host = sys.argv[1]
    local_port = int(sys.argv[2])

    remote_host = sys.argv[3]
    remote_port = int(sys.argv[4])

    receive_first = sys.argv[5]

    if "True" in receive_first:
        receive_first = True
    else:
        receive_first = False

    server_loop(local_host, local_port,
                remote_host, remote_port, receive_first)


if __name__ == '__main__':
    main()
```

Deze functie verwerkt enkele command line argumenten en start de server loop die luistert naar connecties 


### De code in actie

Op je virtuele server kan je bvb testen tegen een ftp server:

```bash
sudo python proxy.py 192.168.1.203 21 ftp.sun.ac.za 21 True
```

- Poort 21 is een gepriviligeerde poort om op te luisteren, vandaar sudo
- Nu kan je een FTP client instellen op localhost en poort 21

Test zelf deze tool en bekijk het resultaat in de terminal.

In een andere terminal op je virtuele machine kan je een FTP-sessie starten, met het IP-adres van de mahine en default poort 21:

```bash
ftp 192.168.1.203
```

Je zal zien dat je met succes FTP banners binnenkrijgt en gebruikersnaam en paswoord kan sturen en je netjes kan exiten (bye)

