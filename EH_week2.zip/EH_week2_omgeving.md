# Ethical Hacking met Python

KM / Ethical Hacking Week 2

- Opzetten van Kali Linux virtual machine (VM)
- Python 3.10 installeren en een virtuele omgeving voorzien
- Onze IDE
- Git(Hub)
- Projectstructuur
- Static Analyzers

In een latere fase Windows 10 VM. Evaluatieversie: https://developer.microsoft.com/en-us/windows/downloads/virtual-machines/.

## Kali Linux

= onze guest VM

Resources:
https://www.kali.org/downloads/
https://www.kali.org/docs/installation/

Zorgen voor laatste versie

```bash
sudo apt update
apt list --upgradable
sudo apt upgrade
sudo apt dist-upgrade
sudo apt autoremove
```

## Python 

Aanwezig op de meeste systemen. Zoals een mars lander, die je deployt en waarmee je alle kanten uitkan ;-)

Python3 => normaal in orde na de updates hierboven

```bash
python
python3
sudo apt-get upgrade python3
```

We zullen uiteraard werken in een virtual environment, python3-venv installeren

```bash
sudo apt-get install python3-venv
```

Recap gebruik van venv

```bash
mkdir eh_1
python3 -m venv venv
source venv/bin/activate
```

Virtuele omgeving verlaten via deactivate

```bash
deactivate
```

Packages installeren in de virtuele omgeving via pip


```bash
pip install hashcrack
pip install lxml
```

Werken met requirements.txt

```bash
pip uninstall lxml
pip list
pip freeze > requirements.txt
pip install -r requirements.txt
```

Testen via de Python shell

```bash
>>> from lxml import etree
>>> exit()
```

## Onze IDE

We gaan werken met VIM, zodat we overal kunnen coden.

Grapje... :-)

Je bent uiteraard welkom om gebruik te maken van vim, nano, emacs.

Maar we gaan gewoon met VS Code werken. Eenvoudigst: downloaden van code.visualstudio.com/download

En daarna bestand (in folder downloads) installeren met...

```bash
sudo apt-get install ./code_amd64.deb
```

## Coden voor het vak EH

We volgen PEP 8. 

PEP8: https://www.python.org/dev/peps/
pep-0008/.

Enkele richtlijnen. Strenger dan vorig jaar. We gaan dit jaar nog meer op de vorm letten.

- Bovenaan ons programma importeren we de nodige packages
- In gedaante from XXX import YYY
- Elke regel alfabetisch geordend
- Daarna de modules, eveneens alfabetisch geordend
- Daarna komen de functies
- Daarna de klassen indien aanwezig
- Helemaal onderaan de main block

Geen superieur programmeren, het is tenslotte hacken ;-) We willen snelheid, gemak en genoeg betrouwbaar.

## Gebruik van GitHub

- Gebruik maken van een version control system (VCS) is altijd aangeraden om diverse redenen. Git vaakst gebruikt.
- Maak een account aan op GitHub.com => nieuw repository aanmaken
- Lokaal clonen met: 

```bash
git clone git@github.com:admkrm/mijn_repo.git
```

Zorg dat volgende bestanden aanwezig zijn (Github helpt je daarmee):
- README.md: beschrijving van je project en de doelstellingen
- LICENSE: onder welke licentie stel je je project beschikbaar
- .gitignore, bestand dat aangeeft welke bestanden en folders niet in het git repo opgenomen moeten worden
- Een directory met de naam van je project => je Python code hoort in een afzonderlijke folder


## projectstructuur + hoe uit te voeren

- Een Python project bestaat uit modules en packages
- Een module is niets meer dan een Python-bestand (.py)
- Een package beslaat één of meerdere modules binnen één directory. Deze MOET een bestand \_\_init\_\_
.py bevatten. Dit bestand mag leeg zijn, of je kan het gebruiken om bepaalde code uit te voeren als dit package geïmporteerd wordt. Je kan bvb bepaalde functies selecteren en hernoemen om het voor de eindgebruiker eenvoudiger te maken functionaliteit te gebruiken.
- Een package kan op zijn beurt andere packages bevatten. We spreken dan van een top-level package met onderliggende subpackages

Gebruik steeds heldere namen voor packages en modules. PEP8: 
- Voor modules (naam via bestandsnaam): korte namen, geen hoofdletters. Underscores gebruiken wanneer het de leesbaarheid verhoogd.
- Voor packages (naam via directory): korte namen, geen hoofdletters, GEEN underscores.


### Een directory-structuur voor projecten

- Eén top-level package in een folder: met (lege) \_\_init\_\_.py
- Met op zijn beurt verschillende sub-packages (telkens een folder)
- Elke sub-package bevat een \_\_init\_\_.py
- Je kan ook folders hebben voor bvb media-bestanden: geen package want \_\_init\_\_.py ontbreekt
- Top-level package bevat ook een \_\_main\_\_.py. Dit bestand wordt uitgevoerd wanneer je dit package direct uitvoert

Bekijk dit even hier: https://docs.python.org/3/tutorial/modules.html

Je voert uit als volgt: 
```bash
python3 -m toplevelpackage
```
(https://peps.python.org/pep-0338/)

### Een module importeren

Doe je als volgt. Eenmaal geïmporteerd: toegang tot variabelen, functies en klassen.

```python
import requests
```

Een module importeren = de module runnen, eventueel ook nieuwe imports binnen deze module

```python
#!/usr/bin/env python3

def open():
    print("Ik doe open.")

def close():
    print("Ik ga sluiten.")
```

Dit bestand heet open_winkel.py. In dezelfde dir hebben we een ander bestand die deze module wil gebruiken:

```python
import open_winkel

open_winkel.open()
open_winkel.close()
```
 
De namespace van open() en close() is open_winkel. 

#### Bepaalde functies uit modules importeren

Om open te kunnen gebruiken zonder de module te moeten noemen...

```python
from open_winkel import open
open()
```

```python
from open_winkel import open, close
open()
close()
```

#### Shadowing

open() is reeds een ingebouwde Python-functie en als je open() uitvoert, voer je eigenlijk de ingebouwde functie uit. Functienaam veranderen in de module? Ja, indien je de auteur bent. Anders: alias


```python
from open_winkel import open as winkel_open
from open_winkel import close

winkel_open()
close()
```

#### Geneste Packages

Packages kunnen andere packages bevatten. Je kan op deze manier verwijzen naar modules

```python
import toplevelpackage.data.data_loader
```

We noemen dit absolute imports (in tegenstelling tot relatieve imports) en gaan steeds op deze manier te werk!

In complexe en diep geneste projecten kan dit omslachtig worden. Probeer de structuur en de nesting overzichtelijk te houden. 2 tot 3 packages diep, liefst niet dieper 

Je kan ook met een alias werken:
```python
from musicapp.player.data.library.song import play
play()
```

Je kan ook kiezen voor een deel namespace:
```python
from musicapp.player.data.library import song
song.play()
```

#### Nooit import all

```python
from open_winkel import *  # nooit doen, ok?
```

#### Package Entry Points
Top-level package heeft een \_\_main\_\_. Dit bestand wordt automatisch uitgevoerd (na de \_\_init\_\_.py) wanneer dit package wordt uitgevoerd (niet wanneer geïmporteerd). Wanneer je dit bestand weglaat kan het niet direct worden uitgevoerd (enkel geïmporteerd).

```python
def main():
    # Alle code om je package te starten

if __name__ == "__main__":
    main()
```

## Je experimenteert met enkele static analyzers

- Zeer handige tools
- Lezen je broncode
- Checken op problemen en afwijkingen van de standaard
- Sommigen kennen ze al door gebruik binnen VS Code

### Linter: Pylint

- Is een linter-tool
- Een linter kijkt je broncode na op vaak gemaakte fouten, mogelijke fouten en stijlafwijkingen. 
- Twee vaakste gebruikte: Pylint en PyFlakes
- Pylint is wellicht de meest veelzijdige
- Werkt goed out-of-the-box en tegelijk ook aanpasbaar
- Installeer bij voorkeur in je virtuele omgeving

```bash
pip install pylint
pylint mijn_bestand.py # analyzeren van een bestand
pylint mijn_project # analyzeren van een volledig package of module
```

Hoe pylint automatisch activeren in VSCode? Settings: python > Linting Enabled: Whether to lint Python files aanvinken

```python
# pylint: disable=missing-docstring

def wandelen(): # pylint: disable=missing-docstring
    geblesseerd = False
    print(spieren)
    return stijfheid
```

Ook mogelijk een pylintrc bestand te creëren in de root dir van je project

```bash
pylint --generate-rcfile > pylintrc
```

Pylint runnen met dit algemeen bestand:

```bash
pylint --rcfile=myrcfile mijn_bestand.py
```

Documentatie: https://pylint.readthedocs.io/.

### Linter+: Flake8 

- Combinatie van 3 static analyzers:
    - PyFlakes is een linter. Sneller en minder valse positieven dan Pylint. Geen styling-regels.
    - Pycodestyle checkt de stijl en zorgt voor PEP 8-compliancy
    - Mccabe checkt de McCabe (or Cyclomatic) complexiteit van je code. Waarschuwt als de structuur van je code te complex wordt

Installeren met pip, in je virtuele omgeving:

```bash
pip install flake8
```

Runnen doe je zo:

```bash
flake8 mijn_bestand.py
```

Veel minder snel aan het klagen over bvb ontbreken van docstring. Je kan dit wel activeren.

Standaard worden enkel PyFlakes en pcodestyle uitgevoerd (genoeg voor ons op dit moment). Wil je toch proberen:

```bash
flake8 --max-complexity 10 mijn_bestand.py
```

Als je Flake8 iets (waar Flake8 over struikelt) wil laten negeren, gebruik dan een inline # noqa comment (op de lijn waar de zgn fout zich voordoet), gevolgd door de error-code die je wil laten negeren. 

```python
def wandelen(): 
    geblesseerd = False  # noqa F841
    print(spieren)  # noqa F821, F841
    return stijfheid  # noqa
```

- Eerste noqa: negeren waarschuwing F841
- Tweede noqa: 2 waarschuwingen negeren
- Derde noqa: alle mogelijke waarschuwingen negeren

Flake8 ondersteunt eveneens configuratie-bestanden. In de project-root kan je en .flake8-bestand toevoegen. Je vindt alle nodige info in de documentatie. Een voorbeeld:

```bash
[flake8]
max-complexity = 10
```

Documentatie: https://flake8.readthedocs.io/.


### Autoformatting: autopep8

- Andere nuttige tools zijn autoformatters
- Passen automatisch je code aan zodat ze PEP8-compliant is
- Autopep8 gebruikt pcodetyle (onderdeel van Flake8)
- Standaard past autopep enkel witruimte aan, maar met het --aggressive argument worden ook extra aanpassingen uitgevoerd
- Met 2x dit argument cleant het zelfs nog beter ;-)
- Documentatie:  https://pypi.org/project/autopep8/ 

Installeren:
```bash
pip install autopep8
```

Meest grondige vorm van aanpassen (in-place, ipv een kopie maken, het standaard gedrag):
```bash
autopep8 --in-place --aggressive --aggressive mijn_bestand.py
```

### Autoformatting: Black

- Gaat ervan uit dat je PEP8 volledig wil volgen
- Geeft weinig opties

Like autopep8, you install black with pip, although it requires Python
3.6 or later. To format a file with it, pass the filename:

Installeren:
```bash
pip install black
```

```bash
black mijn_bestand.py
```

Documentatie: https://black.readthedocs.io/
of: black --help in de terminal.