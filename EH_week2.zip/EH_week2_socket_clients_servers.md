# Netwerktools in Python: socket clients en servers

KM / Ethical Hacking Week 2

## Intro

Mogelijkheden van netwerktoegang voor een aanvaller: 
- scannen naar hosts
- Pakketten injecteren
- Data sniffen
- Vanop afstand hosts exploiteren

Eens je toegang hebt tot een host: vaak geen tools om een aanval uit te voeren. Geen netcat, geen wireshark,... een Python install daarentegen :-)

De voorbeelden die we zien: clients, servers, een tcp proxy. Een eigen netcat inclusief command shell
Belangrijk om deze goed te begrijpen en ermee aan de slag te gaan in het licht van wat volgt.

Basis van Python networking: 
- de socket module
- ondanks een aantal 3rd party tools om servers en clients te maken in Python
- biedt alles dat noodzakelijk is om snel TCP/UDP clients en servers te maken 

Links:
- https://docs.python.org/3/library/socket.html
- https://realpython.com/python-sockets/


## Een eenvoudige TCP Client

Eenvoudige TCP client, deze structuur zal je vaak gebruiken

```python
import socket

HOST = 'www.google.com'
PORT = 80

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Socket object aanmaken
client.connect((HOST, PORT))  # De client verbinden

client.send(b'GET / HTTP/1.1\r\nHost: google.com\r\n\r\n')  # data versturen als bytes
response = client.recv(4096)  # data ontvangen
print(response.decode('utf-8'))

client.close()
```

- AF_INET parameter: IP4 adres of hostname
- SOCK_STREAM parameter: TCP client
- We gaan ervan uit dat de connectie altijd zal lukken, dat de server verwacht dat we eerst data gaan sturen (ipv data te sturen en antwoord af te wachten), dat de server tijdig data zal terugsturen  

## Een eenvoudige UDP Client

Een User Datagram Protocol (UDP) client is niet zo heel verschillend van een TCP client.

```python
import socket

HOST = '127.0.0.1'
PORT = 9997

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # Socket object aanmaken
client.sendto(b'AAABBBCCC', (HOST, PORT))  # Data opsturen

data, address = client.recvfrom(4096)  # Data ontvangen
print(data.decode('utf-8'))
print(address.decode('utf-8'))

client.close()
```

- Socket type hier SOCK_DGRAM
- UDP is connectieloos, dus geen connect()
- recvfrom() om UDP data te ontvangen
- Deze data bevat zowel data als details van de remote host en port


## Een eenvoudige TCP Server

Niet veel complexer dan het maken van een client. We starten met een eenvoudige multithreaded TCP server. We zullen dit model in wat volgt nog uitbreiden.

```python
import socket
import threading

IP = '0.0.0.0'
PORT = 9998


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((IP, PORT))
    server.listen(5)
    print(f'[*] Listening on {IP}:{PORT}')

    while True:
        client, address = server.accept()
        print(f'[*] Accepted connection from {address[0]}:{address[1]}')
        client_handler = threading.Thread(target=handle_client, args=(client,))
        client_handler.start()


def handle_client(client_socket):
    with client_socket as sock:
        request = sock.recv(1024)
        print(f'[*] Received: {request.decode("utf-8")}')
        sock.send(b'ACKKK')


if __name__ == '__main__':
    main()
```

- We geven IP-adres en de poort op dewelke we de server willen laten luisteren
- We laten de server luisteren met een maximum backlog van 5 connecties
- We plaatsen de server in een main loop, zodat hij wacht voor een inkomende connectie
- Wanneer een client connecteert ontvangen we de de client socket in een client variabele en de connectiedetails in de address variabele
- We maken dan een nieuw thread object dat wijst naar onze handle_client functie en we geven het client socket object mee als argument
- We starten dan de thread om de client connectie af te handelen, terwijl op dat moment de main server loop klaar is om een andere inkomende connectie aan te nemen 
- De handle_client functie zorgt voor de recv() en stuurt dan een eenvoudige boodschap terug naar de client

Je kan de tcp client die we eerder zagen gebruiken om wat testpakketten naar de server te sturen.


## Een Python-alternatief voor netcat

Netcat: lezen en schrijven van data over het netwerk, remote commands uitvoeren, bestanden heen en terug sturen, een remote shell openen.

Netcat wordt - ter beveiliging - vaak verwijderd van systemen. 

De start:

```python
import argparse
import socket
import shlex
import subprocess
import sys
import textwrap
import threading


def execute(cmd):
    cmd = cmd.strip()
    if not cmd:
        return
    output = subprocess.check_output(shlex.split(cmd),
                                     stderr=subprocess.STDOUT)
    return output.decode()
```

- Importeren noodzakelijke libraries
- Opzetten van de execute-functie, die een commando ontvangt, uitvoert en de output teruggeeft als string
- Gebruik van de subprocess library. Voorziet interfave om processes aan te maken die aantal manieren voorziet om met clients te interageren
- Hier gebruiken we de check_output method dat een commando uitvoert op het lokale OS en de output teruggeeft

Vervolgens de main-block om commandline argumenten te behandelen en de overige functies aan te roepen:

```python
if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='BHP Net Tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent('''Example:
          netcat.py -t 192.168.1.108 -p 5555 -l -c # command shell
          netcat.py -t 192.168.1.108 -p 5555 -l -u=mytest.whatisup # upload to file
          netcat.py -t 192.168.1.108 -p 5555 -l -e=\"cat /etc/passwd\" # execute command
          echo 'ABCDEFGHI' | ./netcat.py -t 192.168.1.108 -p 135 # echo local text to server port 135
          netcat.py -t 192.168.1.108 -p 5555 # connect to server
          '''))
    parser.add_argument('-c', '--command', action='store_true', help='initialize command shell')
    parser.add_argument('-e', '--execute', help='execute specified command')
    parser.add_argument('-l', '--listen', action='store_true', help='listen')
    parser.add_argument('-p', '--port', type=int, default=5555, help='specified port')
    parser.add_argument('-t', '--target', default='192.168.1.203', help='specified IP')
    parser.add_argument('-u', '--upload', help='upload file')
    args = parser.parse_args()
    if args.listen:
        buffer = ''
    else:
        buffer = sys.stdin.read()

    nc = NetCat(args, buffer.encode('utf-8'))
    nc.run()
```

- Gebruik van de argparse module om de command line interface te maken
- Door gebruik van argumenten kan een bestand worden opgeladen, een commando uitgevoerd of een shell gestart
    - Toevoegen van voorbeelden van gebruik (via --help)
    - -c zorgt voor een interactieve shell
    - -e voert een specifiek commando uit
    - -l zet een listener op
    - -p specificeert de poort om mee te communiceren
    - -t specificeert het ip-adres van de doelmachine
    - -u naam van bestand om te uploaden
- Zowel zender als ontvanger kunnen dit programma gebruiken, de argumenten bepalen of je wil sturen of luisteren
- -c, -e en -u impliceren gebruik van -l, omdat ze toepasselijk zijn op een listener
- De zenderkant maakt connectie met de listener en hoeft enkel -t en -p te gebruiken om met de target listener te connecteren
- Wanneer we een listener opzetten instantiëren we het NetCat object met een lege bufferstring. In het andere geval zenden we de buffercontent van stdin.
Otherwise, we send the buffer content from stdin.
- Uiteindelijk roepen we de run method aan om onze netcat op te starten

Vervolgens voegen we volgende code toe boven de main block

```python
class NetCat:
    def __init__(self, args, buffer=None):
        self.args = args
        self.buffer = buffer
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def run(self):
        if self.args.listen:
            self.listen()
        else:
            self.send()
```

- Initialiseren van het NetCat object met de argumenten van de command line en de buffer
- Vervolgens het socket object creëren
- De run method, gebruikt om het NetCat object te managen delegeert de uitvoering naar twee methods: listen of send 

Vervolgens schrijven we de send method:

```python
    def send(self):
        self.socket.connect((self.args.target, self.args.port))
        if self.buffer:
            self.socket.send(self.buffer)

        try:
            while True:
                recv_len = 1
                response = ''
                while recv_len:
                    data = self.socket.recv(4096)
                    recv_len = len(data)
                    response += data.decode()
                    if recv_len < 4096:
                        break
                if response:
                    print(response)
                    buffer = input('> ')
                    buffer += '\n'
                    self.socket.send(buffer.encode())
        except KeyboardInterrupt:
            print('User terminated.')
            self.socket.close()
            sys.exit()
```

- We connecteren met het target en de gekozen poort
- Indien we een buffer hebben sturen we die eerst naar het target
- We gebruiken een try/except blok om de connectie met CTRL-C handmatig te kunnen afsluiten
- We starten een loop om data van het target te ontvangen. Indien geen data meer stopt de loop. In het andere geval drukken we de response data af en pauzeren om interactieve input te krijgen, die input te versturen en laten we de loop verder gaan
- CTRL-C (KeyboardInterrupt) stopt de loop en sluit de socket connectie

Nu buigen we ons over de listen method:

```python
    def listen(self):
        print('listening')
        self.socket.bind((self.args.target, self.args.port))
        self.socket.listen(5)
        while True:
            client_socket, _ = self.socket.accept()
            client_thread = threading.Thread(target=self.handle, args=(client_socket,))
            client_thread.start()
```

- Deze method bindt zich met de gekozen target en poort en start met luisteren in een loop
- De verbonden socket wordt doorgegeven aan de handle method

Deze handle method bevat de logica voor file uploads, uitvoeren van commando's en de interactieve shell. Onze tool kan dit doen wanneer ze operereert als listener:

```python
    def handle(self, client_socket):
            if self.args.execute:
                output = execute(self.args.execute)
                client_socket.send(output.encode())

            elif self.args.upload:
                file_buffer = b''
                while True:
                    data = client_socket.recv(4096)
                    if data:
                        file_buffer += data
                        print(len(file_buffer))
                    else:
                        break

                with open(self.args.upload, 'wb') as f:
                    f.write(file_buffer)
                message = f'Saved file {self.args.upload}'
                client_socket.send(message.encode())

            elif self.args.command:
                cmd_buffer = b''
                while True:
                    try:
                        client_socket.send(b' #> ')
                        while '\n' not in cmd_buffer.decode():
                            cmd_buffer += client_socket.recv(64)
                        response = execute(cmd_buffer.decode())
                        if response:
                            client_socket.send(response.encode())
                        cmd_buffer = b''
                    except Exception as e:
                        print(f'server killed {e}')
                        self.socket.close()
                        sys.exit()
```

- Deze method voert de taken uit overeenkomstig het command line argument dat het ontvangt
- Dient een command te worden uitgevoerd: command wordt doorgegeven aan de execute functie en output wordt teruggestuurd naar de socket
- Dient een bestand opgeladen dan wordt een loop gestart om te luisteren naar de content op de listening socket en de data te ontvangen tot alle data gearriveerd is. Tot slot wordt alle data weggeschreven naar een bestand
- Als een shell moet worden gecreëerd dan wordt een loop gestart, sturen we een prompt naar de sender en wordt gewacht op een terugkerende command string. We voeren dan het command uit via de executy functie en geven de output van het command terug aan de sender
- De shell scant voor een newline karakter om te bepalen wanneer een commando uit te voeren (compatibel met netcat, met deze tool als listener)
- Als je send vanaf een eigen Python client, vergeet niet om het newline character toe te voegen


### De code in actie

Probeer netcat.py uit met --help en bestudeer rustig de output. 

```bash
python netcat.py --help
```

Je kan op je virtuele machine een listener opzetten met gebruik van het eigen IP-adres en poort 5555 om een command shell te bekomen:

```bash
python netcat.py -t 192.168.1.203 -p 5555 -l -c
```

Op je lokale machine kan je het script uitvoeren in client mode. ! Het script leest van stdin en doet dit tot het een end-of-file marker (EOF) krijgt. Je stuurt een EOF met CTRL-D.

```bash
% python netcat.py -t 192.168.1.203 -p 5555
CTRL-D
<BHP:#> ls -la
...
<BHP: #> uname -a
...
```

We ontvangen een custom command shell. Omdat we ons op een Unix host bevinden kunnen we lokale commando's uitvoeren en ontvangen we output als resultaat, alsof we via SSH zijn ingelogd, of lokaal aktief op de server

Om een enkel command uit te voeren doen we het volgende op de client:

```bash
python netcat.py -t 192.168.1.203 -p 5555 -l -e="cat /etc/passwd"
```

Wanneer we nu connecteren met onze virtuele machine vanuit de lokale machine krijgen we de output van dit commando...

```bash
python netcat.py -t 192.168.1.203 -p 5555
```

We kunnen ook netcat gebruiken op onze lokale machine en krijgen dezelfde output binnen...

```bash
nc 192.168.1.203 5555
```

Finally, we could use the client to send out requests the good, old-
fashioned way:

We kunnen ook onze client gebruiken om requests te sturen:

```bash
echo -ne "GET / HTTP/1.1\r\nHost: website.com\r\n\r\n" |python ./netcat.py -t website.com
-p 80
```

Voila, een goed startpunt om met client en server sockets aan de slag te gaan in Python. Je kan nu je eigen creativiteit gebruiken om deze tool verder uit te bouwen. 